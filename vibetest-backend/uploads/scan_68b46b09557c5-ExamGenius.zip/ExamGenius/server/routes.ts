import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, loginSchema, insertMockExamSchema, insertAiExplanationSchema,
  insertSyllabusSchema, insertPastQuestionPaperSchema, insertPastQuestionSchema,
  insertSyllabusProgressSchema
} from "@shared/schema";
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

const JWT_SECRET = process.env.JWT_SECRET || 'prepnaija-secret-key';

// Middleware to verify JWT token
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Auth Routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });

      // Create JWT token
      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET);

      res.status(201).json({
        message: 'User registered successfully',
        user: { ...user, password: undefined },
        token
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET);

      res.json({
        message: 'Login successful',
        user: { ...user, password: undefined },
        token
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get('/api/auth/me', authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json({ ...user, password: undefined });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Subjects Routes
  app.get('/api/subjects', async (req, res) => {
    try {
      const subjects = await storage.getAllSubjects();
      res.json(subjects);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // User Progress Routes
  app.get('/api/progress', authenticateToken, async (req: any, res) => {
    try {
      const progress = await storage.getUserProgress(req.user.userId);
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post('/api/progress/:subjectId', authenticateToken, async (req: any, res) => {
    try {
      const { subjectId } = req.params;
      const progressData = req.body;
      
      const progress = await storage.updateUserProgress(req.user.userId, subjectId, progressData);
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Mock Exams Routes
  app.get('/api/mock-exams', authenticateToken, async (req: any, res) => {
    try {
      const exams = await storage.getUserMockExams(req.user.userId);
      res.json(exams);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post('/api/mock-exams', authenticateToken, async (req: any, res) => {
    try {
      const examData = insertMockExamSchema.parse({
        ...req.body,
        userId: req.user.userId
      });
      
      const exam = await storage.createMockExam(examData);
      res.status(201).json(exam);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch('/api/mock-exams/:id', authenticateToken, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const exam = await storage.updateMockExam(id, updates);
      if (!exam) {
        return res.status(404).json({ message: 'Mock exam not found' });
      }
      
      res.json(exam);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Questions Routes
  app.get('/api/questions/random', authenticateToken, async (req: any, res) => {
    try {
      const { subjectIds, count = 10, examType } = req.query;
      const subjects = Array.isArray(subjectIds) ? subjectIds : [subjectIds];
      
      const questions = await storage.getRandomQuestions(subjects, parseInt(count), examType);
      res.json(questions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // AI Explanations Routes
  app.post('/api/explanations', authenticateToken, async (req: any, res) => {
    try {
      const explanationData = insertAiExplanationSchema.parse({
        ...req.body,
        userId: req.user.userId
      });
      
      const explanation = await storage.createExplanation(explanationData);
      res.status(201).json(explanation);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get('/api/explanations', authenticateToken, async (req: any, res) => {
    try {
      const explanations = await storage.getUserExplanations(req.user.userId);
      res.json(explanations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // OCR Route (placeholder for future implementation)
  app.post('/api/ocr', authenticateToken, async (req: any, res) => {
    try {
      // TODO: Implement OCR functionality using Tesseract or similar
      // For now, return a placeholder response
      const { imageUrl } = req.body;
      
      // Simulate OCR processing
      const ocrText = "Sample OCR text from uploaded image. Solve for x: 2x² + 5x - 3 = 0";
      
      res.json({ 
        success: true, 
        text: ocrText,
        confidence: 0.98 
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // AI Explanation Generation (placeholder for OpenAI integration)
  app.post('/api/ai/explain', authenticateToken, async (req: any, res) => {
    try {
      const { question, subject } = req.body;
      
      // TODO: Integrate with OpenAI API
      // For now, return a structured response
      const explanation = {
        question: question,
        subject: subject,
        steps: [
          {
            stepNumber: 1,
            title: "Identify the equation type",
            description: "This is a quadratic equation in the form ax² + bx + c = 0, where a = 2, b = 5, c = -3",
            color: "blue"
          },
          {
            stepNumber: 2,
            title: "Apply the quadratic formula",
            description: "x = (-b ± √(b² - 4ac)) / 2a\nx = (-5 ± √(25 + 24)) / 4",
            color: "green"
          },
          {
            stepNumber: 3,
            title: "Simplify the discriminant",
            description: "√49 = 7\nx = (-5 ± 7) / 4",
            color: "yellow"
          },
          {
            stepNumber: 4,
            title: "Calculate both solutions",
            description: "x₁ = (-5 + 7) / 4 = 2/4 = 1/2\nx₂ = (-5 - 7) / 4 = -12/4 = -3",
            color: "purple"
          }
        ],
        finalAnswer: "x = 1/2 or x = -3",
        explanation: "This quadratic equation has two real solutions. The positive solution x = 1/2 and negative solution x = -3 both satisfy the original equation."
      };
      
      res.json(explanation);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Achievements Routes
  app.get('/api/achievements', authenticateToken, async (req: any, res) => {
    try {
      const achievements = await storage.getUserAchievements(req.user.userId);
      res.json(achievements);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Syllabi Routes
  app.get('/api/syllabi', authenticateToken, async (req: any, res) => {
    try {
      const { examType, subjectId } = req.query;
      if (examType && subjectId) {
        const syllabi = await storage.getSyllabusByExamAndSubject(examType as string, subjectId as string);
        res.json(syllabi);
      } else {
        res.status(400).json({ message: 'examType and subjectId are required' });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get('/api/syllabi/:id', authenticateToken, async (req: any, res) => {
    try {
      const syllabus = await storage.getSyllabus(req.params.id);
      if (!syllabus) {
        return res.status(404).json({ message: 'Syllabus not found' });
      }
      res.json(syllabus);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post('/api/syllabi', authenticateToken, async (req: any, res) => {
    try {
      const syllabusData = insertSyllabusSchema.parse(req.body);
      const syllabus = await storage.createSyllabus(syllabusData);
      res.status(201).json(syllabus);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Past Question Papers Routes
  app.get('/api/past-question-papers', authenticateToken, async (req: any, res) => {
    try {
      const { examType, subjectId, year } = req.query;
      const papers = await storage.getPastQuestionPapers(
        examType as string,
        subjectId as string, 
        year ? parseInt(year as string) : undefined
      );
      res.json(papers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get('/api/past-question-papers/:id', authenticateToken, async (req: any, res) => {
    try {
      const paper = await storage.getPastQuestionPaper(req.params.id);
      if (!paper) {
        return res.status(404).json({ message: 'Past question paper not found' });
      }
      res.json(paper);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post('/api/past-question-papers', authenticateToken, async (req: any, res) => {
    try {
      const paperData = insertPastQuestionPaperSchema.parse(req.body);
      const paper = await storage.createPastQuestionPaper(paperData);
      res.status(201).json(paper);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // File upload endpoint (placeholder for actual file handling)
  app.post('/api/upload/pdf', authenticateToken, async (req: any, res) => {
    try {
      // In a real implementation, this would:
      // 1. Handle multipart/form-data upload
      // 2. Validate file type and size
      // 3. Upload to cloud storage (S3, Cloudinary, etc.)
      // 4. Extract questions using OCR
      // 5. Store in database
      
      // For now, return a mock response
      const mockResponse = {
        url: `https://storage.prepnaija.com/papers/mock-${Date.now()}.pdf`,
        fileName: `mock-paper-${Date.now()}.pdf`,
        fileSize: 1024 * 1024 * 2, // 2MB
        message: 'File uploaded successfully (mock implementation)',
      };
      
      res.json(mockResponse);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch('/api/past-question-papers/:id', authenticateToken, async (req: any, res) => {
    try {
      const updatedPaper = await storage.updatePastQuestionPaper(req.params.id, req.body);
      if (!updatedPaper) {
        return res.status(404).json({ message: 'Past question paper not found' });
      }
      res.json(updatedPaper);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Past Questions Routes
  app.get('/api/past-questions', authenticateToken, async (req: any, res) => {
    try {
      const { paperId, examType, subjectId, year, topic } = req.query;
      
      if (paperId) {
        const questions = await storage.getPastQuestionsByPaper(paperId as string);
        res.json(questions);
      } else {
        const questions = await storage.getPastQuestionsByFilters(
          examType as string,
          subjectId as string,
          year ? parseInt(year as string) : undefined,
          topic as string
        );
        res.json(questions);
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get('/api/past-questions/:id', authenticateToken, async (req: any, res) => {
    try {
      const question = await storage.getPastQuestion(req.params.id);
      if (!question) {
        return res.status(404).json({ message: 'Past question not found' });
      }
      res.json(question);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post('/api/past-questions', authenticateToken, async (req: any, res) => {
    try {
      const questionData = insertPastQuestionSchema.parse(req.body);
      const question = await storage.createPastQuestion(questionData);
      res.status(201).json(question);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Syllabus Progress Routes
  app.get('/api/syllabus-progress', authenticateToken, async (req: any, res) => {
    try {
      const { syllabusId } = req.query;
      const progress = await storage.getUserSyllabusProgress(req.user.userId, syllabusId as string);
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch('/api/syllabus-progress', authenticateToken, async (req: any, res) => {
    try {
      const { syllabusId, topicId, ...progressData } = req.body;
      const progress = await storage.updateSyllabusProgress(req.user.userId, syllabusId, topicId, progressData);
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
