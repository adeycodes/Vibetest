import { 
  type User, type InsertUser, type Subject, type InsertSubject,
  type Question, type InsertQuestion, type UserProgress, type InsertUserProgress,
  type MockExam, type InsertMockExam, type AiExplanation, type InsertAiExplanation,
  type UserAchievement, type InsertUserAchievement, type Syllabus, type InsertSyllabus,
  type PastQuestionPaper, type InsertPastQuestionPaper, type PastQuestion, type InsertPastQuestion,
  type SyllabusProgress, type InsertSyllabusProgress
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Subjects
  getAllSubjects(): Promise<Subject[]>;
  getSubject(id: string): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;

  // Questions
  getQuestionsBySubject(subjectId: string, examType?: string): Promise<Question[]>;
  getQuestion(id: string): Promise<Question | undefined>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  getRandomQuestions(subjectIds: string[], count: number, examType?: string): Promise<Question[]>;

  // User Progress
  getUserProgress(userId: string): Promise<UserProgress[]>;
  getUserProgressBySubject(userId: string, subjectId: string): Promise<UserProgress | undefined>;
  updateUserProgress(userId: string, subjectId: string, progress: Partial<InsertUserProgress>): Promise<UserProgress>;

  // Mock Exams
  getUserMockExams(userId: string): Promise<MockExam[]>;
  getMockExam(id: string): Promise<MockExam | undefined>;
  createMockExam(exam: InsertMockExam): Promise<MockExam>;
  updateMockExam(id: string, updates: Partial<MockExam>): Promise<MockExam | undefined>;

  // AI Explanations
  getUserExplanations(userId: string): Promise<AiExplanation[]>;
  getExplanation(id: string): Promise<AiExplanation | undefined>;
  createExplanation(explanation: InsertAiExplanation): Promise<AiExplanation>;

  // Achievements
  getUserAchievements(userId: string): Promise<UserAchievement[]>;
  createAchievement(achievement: InsertUserAchievement): Promise<UserAchievement>;

  // Syllabi
  getSyllabusByExamAndSubject(examType: string, subjectId: string): Promise<Syllabus[]>;
  getSyllabus(id: string): Promise<Syllabus | undefined>;
  createSyllabus(syllabus: InsertSyllabus): Promise<Syllabus>;

  // Past Question Papers
  getPastQuestionPapers(examType?: string, subjectId?: string, year?: number): Promise<PastQuestionPaper[]>;
  getPastQuestionPaper(id: string): Promise<PastQuestionPaper | undefined>;
  createPastQuestionPaper(paper: InsertPastQuestionPaper): Promise<PastQuestionPaper>;
  updatePastQuestionPaper(id: string, updates: Partial<PastQuestionPaper>): Promise<PastQuestionPaper | undefined>;

  // Past Questions
  getPastQuestionsByPaper(paperId: string): Promise<PastQuestion[]>;
  getPastQuestionsByFilters(examType?: string, subjectId?: string, year?: number, topic?: string): Promise<PastQuestion[]>;
  getPastQuestion(id: string): Promise<PastQuestion | undefined>;
  createPastQuestion(question: InsertPastQuestion): Promise<PastQuestion>;

  // Syllabus Progress
  getUserSyllabusProgress(userId: string, syllabusId?: string): Promise<SyllabusProgress[]>;
  updateSyllabusProgress(userId: string, syllabusId: string, topicId: string, progress: Partial<InsertSyllabusProgress>): Promise<SyllabusProgress>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private subjects: Map<string, Subject> = new Map();
  private questions: Map<string, Question> = new Map();
  private userProgress: Map<string, UserProgress> = new Map();
  private mockExams: Map<string, MockExam> = new Map();
  private aiExplanations: Map<string, AiExplanation> = new Map();
  private userAchievements: Map<string, UserAchievement> = new Map();
  private syllabi: Map<string, Syllabus> = new Map();
  private pastQuestionPapers: Map<string, PastQuestionPaper> = new Map();
  private pastQuestions: Map<string, PastQuestion> = new Map();
  private syllabusProgress: Map<string, SyllabusProgress> = new Map();

  constructor() {
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Initialize default subjects
    const defaultSubjects: Subject[] = [
      { id: randomUUID(), name: "Mathematics", icon: "calculator", color: "blue", description: "Algebra, Geometry, Statistics, and more" },
      { id: randomUUID(), name: "English Language", icon: "book", color: "red", description: "Grammar, Comprehension, Literature" },
      { id: randomUUID(), name: "Physics", icon: "atom", color: "purple", description: "Mechanics, Waves, Electricity" },
      { id: randomUUID(), name: "Chemistry", icon: "flask", color: "green", description: "Organic, Inorganic, Physical Chemistry" },
      { id: randomUUID(), name: "Biology", icon: "dna", color: "emerald", description: "Genetics, Ecology, Human Biology" },
      { id: randomUUID(), name: "Economics", icon: "chart-pie", color: "yellow", description: "Micro, Macro, Development Economics" },
    ];

    defaultSubjects.forEach(subject => {
      this.subjects.set(subject.id, subject);
    });

    // Initialize sample past question papers
    const mathSubject = defaultSubjects.find(s => s.name === "Mathematics");
    const englishSubject = defaultSubjects.find(s => s.name === "English Language");
    const physicsSubject = defaultSubjects.find(s => s.name === "Physics");

    if (mathSubject && englishSubject && physicsSubject) {
      const samplePapers: PastQuestionPaper[] = [
        {
          id: randomUUID(),
          examType: "WAEC",
          subjectId: mathSubject.id,
          year: 2023,
          title: "WAEC Mathematics 2023",
          pdfUrl: "https://storage.prepnaija.com/papers/waec-math-2023.pdf",
          fileName: "waec-math-2023.pdf",
          fileSize: 1024 * 1024 * 3, // 3MB
          totalQuestions: 50,
          isProcessed: true,
          uploadedAt: new Date('2024-01-15'),
        },
        {
          id: randomUUID(),
          examType: "JAMB",
          subjectId: mathSubject.id,
          year: 2022,
          title: "JAMB Mathematics 2022",
          pdfUrl: "https://storage.prepnaija.com/papers/jamb-math-2022.pdf",
          fileName: "jamb-math-2022.pdf",
          fileSize: 1024 * 1024 * 2.5, // 2.5MB
          totalQuestions: 60,
          isProcessed: true,
          uploadedAt: new Date('2023-12-20'),
        },
        {
          id: randomUUID(),
          examType: "WAEC",
          subjectId: englishSubject.id,
          year: 2023,
          title: "WAEC English Language 2023",
          pdfUrl: "https://storage.prepnaija.com/papers/waec-english-2023.pdf",
          fileName: "waec-english-2023.pdf",
          fileSize: 1024 * 1024 * 2.2, // 2.2MB
          totalQuestions: 45,
          isProcessed: true,
          uploadedAt: new Date('2024-01-10'),
        },
        {
          id: randomUUID(),
          examType: "NECO",
          subjectId: physicsSubject.id,
          year: 2021,
          title: "NECO Physics 2021",
          pdfUrl: "https://storage.prepnaija.com/papers/neco-physics-2021.pdf",
          fileName: "neco-physics-2021.pdf",  
          fileSize: 1024 * 1024 * 4.1, // 4.1MB
          totalQuestions: 50,
          isProcessed: false,
          uploadedAt: new Date('2023-11-05'),
        },
        {
          id: randomUUID(),
          examType: "GCE",
          subjectId: mathSubject.id,
          year: 2020,
          title: "GCE Mathematics 2020",
          pdfUrl: "https://storage.prepnaija.com/papers/gce-math-2020.pdf",
          fileName: "gce-math-2020.pdf",
          fileSize: 1024 * 1024 * 2.8, // 2.8MB
          totalQuestions: 40,
          isProcessed: true,
          uploadedAt: new Date('2023-10-15'),
        },
      ];

      samplePapers.forEach(paper => {
        this.pastQuestionPapers.set(paper.id, paper);
      });

      // Initialize sample syllabi
      const sampleSyllabi: Syllabus[] = [
        {
          id: randomUUID(),
          examType: "WAEC",
          subjectId: mathSubject.id,
          year: 2024,
          topics: [
            {
              id: "algebra",
              title: "Algebra",
              subtopics: [
                "Linear equations and inequalities",
                "Quadratic equations",
                "Simultaneous equations",
                "Indices and logarithms"
              ]
            },
            {
              id: "geometry",
              title: "Geometry and Trigonometry", 
              subtopics: [
                "Angles and polygons",
                "Circle theorems",
                "Trigonometric ratios",
                "Areas and volumes"
              ]
            },
            {
              id: "statistics",
              title: "Statistics and Probability",
              subtopics: [
                "Data presentation",
                "Measures of central tendency",
                "Probability basics",
                "Normal distribution"
              ]
            }
          ],
          objectives: {
            algebra: "Master algebraic manipulation and equation solving",
            geometry: "Understand geometric relationships and trigonometric applications",
            statistics: "Analyze data and calculate probabilities"
          },
          createdAt: new Date('2024-01-01'),
        }
      ];

      sampleSyllabi.forEach(syllabus => {
        this.syllabi.set(syllabus.id, syllabus);
      });
    }
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      isPro: false,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Subjects
  async getAllSubjects(): Promise<Subject[]> {
    return Array.from(this.subjects.values());
  }

  async getSubject(id: string): Promise<Subject | undefined> {
    return this.subjects.get(id);
  }

  async createSubject(insertSubject: InsertSubject): Promise<Subject> {
    const id = randomUUID();
    const subject: Subject = { ...insertSubject, id };
    this.subjects.set(id, subject);
    return subject;
  }

  // Questions
  async getQuestionsBySubject(subjectId: string, examType?: string): Promise<Question[]> {
    return Array.from(this.questions.values()).filter(q => 
      q.subjectId === subjectId && (!examType || q.examType === examType)
    );
  }

  async getQuestion(id: string): Promise<Question | undefined> {
    return this.questions.get(id);
  }

  async createQuestion(insertQuestion: InsertQuestion): Promise<Question> {
    const id = randomUUID();
    const question: Question = { 
      ...insertQuestion, 
      id, 
      createdAt: new Date() 
    };
    this.questions.set(id, question);
    return question;
  }

  async getRandomQuestions(subjectIds: string[], count: number, examType?: string): Promise<Question[]> {
    const allQuestions = Array.from(this.questions.values()).filter(q => 
      subjectIds.includes(q.subjectId || '') && (!examType || q.examType === examType)
    );
    
    // Shuffle and return requested count
    const shuffled = allQuestions.sort(() => Math.random() - 0.5);
    return shuffled.slice(0, count);
  }

  // User Progress
  async getUserProgress(userId: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(p => p.userId === userId);
  }

  async getUserProgressBySubject(userId: string, subjectId: string): Promise<UserProgress | undefined> {
    return Array.from(this.userProgress.values()).find(p => 
      p.userId === userId && p.subjectId === subjectId
    );
  }

  async updateUserProgress(userId: string, subjectId: string, progress: Partial<InsertUserProgress>): Promise<UserProgress> {
    const existing = await this.getUserProgressBySubject(userId, subjectId);
    
    if (existing) {
      const updated = { ...existing, ...progress };
      this.userProgress.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const newProgress: UserProgress = {
        id,
        userId,
        subjectId,
        questionsAnswered: 0,
        questionsCorrect: 0,
        averageScore: '0',
        lastStudied: null,
        ...progress
      };
      this.userProgress.set(id, newProgress);
      return newProgress;
    }
  }

  // Mock Exams
  async getUserMockExams(userId: string): Promise<MockExam[]> {
    return Array.from(this.mockExams.values()).filter(e => e.userId === userId);
  }

  async getMockExam(id: string): Promise<MockExam | undefined> {
    return this.mockExams.get(id);
  }

  async createMockExam(insertExam: InsertMockExam): Promise<MockExam> {
    const id = randomUUID();
    const exam: MockExam = { 
      ...insertExam, 
      id, 
      createdAt: new Date() 
    };
    this.mockExams.set(id, exam);
    return exam;
  }

  async updateMockExam(id: string, updates: Partial<MockExam>): Promise<MockExam | undefined> {
    const exam = this.mockExams.get(id);
    if (!exam) return undefined;
    
    const updated = { ...exam, ...updates };
    this.mockExams.set(id, updated);
    return updated;
  }

  // AI Explanations
  async getUserExplanations(userId: string): Promise<AiExplanation[]> {
    return Array.from(this.aiExplanations.values()).filter(e => e.userId === userId);
  }

  async getExplanation(id: string): Promise<AiExplanation | undefined> {
    return this.aiExplanations.get(id);
  }

  async createExplanation(insertExplanation: InsertAiExplanation): Promise<AiExplanation> {
    const id = randomUUID();
    const explanation: AiExplanation = { 
      ...insertExplanation, 
      id, 
      createdAt: new Date() 
    };
    this.aiExplanations.set(id, explanation);
    return explanation;
  }

  // Achievements
  async getUserAchievements(userId: string): Promise<UserAchievement[]> {
    return Array.from(this.userAchievements.values()).filter(a => a.userId === userId);
  }

  async createAchievement(insertAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const id = randomUUID();
    const achievement: UserAchievement = { 
      ...insertAchievement, 
      id, 
      unlockedAt: new Date() 
    };
    this.userAchievements.set(id, achievement);
    return achievement;
  }

  // Syllabi methods
  async getSyllabusByExamAndSubject(examType: string, subjectId: string): Promise<Syllabus[]> {
    return Array.from(this.syllabi.values()).filter(
      syllabus => syllabus.examType === examType && syllabus.subjectId === subjectId
    );
  }

  async getSyllabus(id: string): Promise<Syllabus | undefined> {
    return this.syllabi.get(id);
  }

  async createSyllabus(syllabus: InsertSyllabus): Promise<Syllabus> {
    const id = randomUUID();
    const newSyllabus: Syllabus = {
      ...syllabus,
      id,
      createdAt: new Date(),
    };
    this.syllabi.set(id, newSyllabus);
    return newSyllabus;
  }

  // Past Question Papers methods
  async getPastQuestionPapers(examType?: string, subjectId?: string, year?: number): Promise<PastQuestionPaper[]> {
    let papers = Array.from(this.pastQuestionPapers.values());
    
    if (examType) {
      papers = papers.filter(paper => paper.examType === examType);
    }
    if (subjectId) {
      papers = papers.filter(paper => paper.subjectId === subjectId);
    }
    if (year) {
      papers = papers.filter(paper => paper.year === year);
    }
    
    return papers.sort((a, b) => b.year - a.year);
  }

  async getPastQuestionPaper(id: string): Promise<PastQuestionPaper | undefined> {
    return this.pastQuestionPapers.get(id);
  }

  async createPastQuestionPaper(paper: InsertPastQuestionPaper): Promise<PastQuestionPaper> {
    const id = randomUUID();
    const newPaper: PastQuestionPaper = {
      ...paper,
      id,
      uploadedAt: new Date(),
    };
    this.pastQuestionPapers.set(id, newPaper);
    return newPaper;
  }

  async updatePastQuestionPaper(id: string, updates: Partial<PastQuestionPaper>): Promise<PastQuestionPaper | undefined> {
    const paper = this.pastQuestionPapers.get(id);
    if (!paper) return undefined;
    
    const updatedPaper = { ...paper, ...updates };
    this.pastQuestionPapers.set(id, updatedPaper);
    return updatedPaper;
  }

  // Past Questions methods
  async getPastQuestionsByPaper(paperId: string): Promise<PastQuestion[]> {
    return Array.from(this.pastQuestions.values())
      .filter(question => question.paperId === paperId)
      .sort((a, b) => a.questionNumber - b.questionNumber);
  }

  async getPastQuestionsByFilters(examType?: string, subjectId?: string, year?: number, topic?: string): Promise<PastQuestion[]> {
    let questions = Array.from(this.pastQuestions.values());
    
    if (examType) {
      questions = questions.filter(q => q.examType === examType);
    }
    if (subjectId) {
      questions = questions.filter(q => q.subjectId === subjectId);
    }
    if (year) {
      questions = questions.filter(q => q.year === year);
    }
    if (topic) {
      questions = questions.filter(q => q.topic?.toLowerCase().includes(topic.toLowerCase()));
    }
    
    return questions.sort((a, b) => b.year - a.year || a.questionNumber - b.questionNumber);
  }

  async getPastQuestion(id: string): Promise<PastQuestion | undefined> {
    return this.pastQuestions.get(id);
  }

  async createPastQuestion(question: InsertPastQuestion): Promise<PastQuestion> {
    const id = randomUUID();
    const newQuestion: PastQuestion = {
      ...question,
      id,
      createdAt: new Date(),
    };
    this.pastQuestions.set(id, newQuestion);
    return newQuestion;
  }

  // Syllabus Progress methods
  async getUserSyllabusProgress(userId: string, syllabusId?: string): Promise<SyllabusProgress[]> {
    let progress = Array.from(this.syllabusProgress.values()).filter(p => p.userId === userId);
    
    if (syllabusId) {
      progress = progress.filter(p => p.syllabusId === syllabusId);
    }
    
    return progress;
  }

  async updateSyllabusProgress(userId: string, syllabusId: string, topicId: string, progress: Partial<InsertSyllabusProgress>): Promise<SyllabusProgress> {
    // Find existing progress or create new
    const existingKey = Array.from(this.syllabusProgress.entries()).find(
      ([_, p]) => p.userId === userId && p.syllabusId === syllabusId && p.topicId === topicId
    )?.[0];

    const id = existingKey || randomUUID();
    const updatedProgress: SyllabusProgress = {
      id,
      userId,
      syllabusId,
      topicId,
      isCompleted: false,
      masteryLevel: 0,
      lastStudied: null,
      questionsAnswered: 0,
      questionsCorrect: 0,
      ...progress,
      lastStudied: new Date(),
    };

    this.syllabusProgress.set(id, updatedProgress);
    return updatedProgress;
  }
}

export const storage = new MemStorage();
