import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { Camera, Upload, Loader2 } from "lucide-react";

interface UploadAreaProps {
  onFileUpload: (file: File) => void;
  isProcessing: boolean;
}

export default function UploadArea({ onFileUpload, isProcessing }: UploadAreaProps) {
  const [isDragActive, setIsDragActive] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      onFileUpload(acceptedFiles[0]);
    }
  }, [onFileUpload]);

  const { getRootProps, getInputProps, isDragActive: dragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif']
    },
    multiple: false,
    maxSize: 10 * 1024 * 1024, // 10MB
    onDragEnter: () => setIsDragActive(true),
    onDragLeave: () => setIsDragActive(false),
  });

  const handleCameraCapture = () => {
    // For web, this would typically open a file input with camera access
    // On mobile, this could trigger the camera directly
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.capture = 'environment'; // Use rear camera on mobile
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        onFileUpload(file);
      }
    };
    input.click();
  };

  if (isProcessing) {
    return (
      <div className="bg-gray-50 rounded-2xl p-8">
        <div className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Processing Your Question</h3>
          <p className="text-gray-600 mb-6">Our AI is analyzing the image and preparing your explanation...</p>
          <div className="bg-primary-50 rounded-lg p-4 max-w-md mx-auto">
            <p className="text-primary-700 text-sm">
              💡 <strong>Tip:</strong> While you wait, make sure your question image has good lighting and clear text for the best results!
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 rounded-2xl p-8">
      <div 
        {...getRootProps()} 
        className={`border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-colors ${
          dragActive || isDragActive
            ? 'border-primary bg-primary-50' 
            : 'border-gray-300 hover:border-primary'
        }`}
      >
        <input {...getInputProps()} />
        <div className="mb-6">
          <Camera className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Upload or Capture Question</h3>
          <p className="text-gray-600">
            {dragActive ? 'Drop your image here!' : 'Drag and drop an image, or click to browse'}
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            type="button"
            onClick={handleCameraCapture}
            className="bg-primary hover:bg-primary-700 text-white px-6 py-3 font-medium"
          >
            <Camera className="mr-2 h-4 w-4" />
            Take Photo
          </Button>
          <Button 
            type="button"
            variant="outline"
            className="border-2 border-gray-300 hover:border-primary text-gray-700 hover:text-primary px-6 py-3 font-medium"
          >
            <Upload className="mr-2 h-4 w-4" />
            Upload Image
          </Button>
        </div>
        
        <p className="text-sm text-gray-500 mt-4">Supports JPG, PNG up to 10MB</p>
      </div>
    </div>
  );
}
