import { CheckCircle } from "lucide-react";

interface Step {
  stepNumber: number;
  title: string;
  description: string;
  color: string;
}

interface SolutionStepsProps {
  steps: Step[];
  finalAnswer: string;
}

const getStepColorClasses = (color: string) => {
  switch (color) {
    case 'blue':
      return 'bg-blue-50 border-blue-400';
    case 'green':
      return 'bg-green-50 border-green-400';
    case 'yellow':
      return 'bg-yellow-50 border-yellow-400';
    case 'purple':
      return 'bg-purple-50 border-purple-400';
    default:
      return 'bg-gray-50 border-gray-400';
  }
};

const getStepNumberClasses = (color: string) => {
  switch (color) {
    case 'blue':
      return 'bg-blue-400 text-white';
    case 'green':
      return 'bg-green-400 text-white';
    case 'yellow':
      return 'bg-yellow-400 text-white';
    case 'purple':
      return 'bg-purple-400 text-white';
    default:
      return 'bg-gray-400 text-white';
  }
};

export default function SolutionSteps({ steps, finalAnswer }: SolutionStepsProps) {
  return (
    <div className="space-y-4">
      {steps.map((step) => (
        <div key={step.stepNumber} className={`rounded-lg p-4 border-l-4 ${getStepColorClasses(step.color)}`}>
          <div className="flex items-start">
            <div className={`rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5 ${getStepNumberClasses(step.color)}`}>
              {step.stepNumber}
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900 mb-1">{step.title}</h4>
              <p className="text-gray-700 text-sm whitespace-pre-line">{step.description}</p>
            </div>
          </div>
        </div>
      ))}

      <div className="bg-gradient-to-r from-primary-50 to-success-50 rounded-lg p-4 border border-primary-200">
        <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
          <CheckCircle className="h-5 w-5 text-success mr-2" />
          Final Answer
        </h4>
        <p className="text-gray-900 font-medium">{finalAnswer}</p>
      </div>
    </div>
  );
}
