import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Play, Volume2, Captions, Expand } from "lucide-react";

export default function VideoPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="bg-gray-900 rounded-xl overflow-hidden mb-6">
      <div className="aspect-video flex items-center justify-center relative">
        {!isPlaying ? (
          <div className="text-center text-white">
            <div 
              className="cursor-pointer hover:scale-110 transition-transform"
              onClick={() => setIsPlaying(true)}
            >
              <Play className="h-16 w-16 mb-4 opacity-80 mx-auto" />
            </div>
            <p className="text-lg">AI Teacher Video Explanation</p>
            <p className="text-sm opacity-80">Duration: 3:45</p>
          </div>
        ) : (
          <div className="w-full h-full bg-gray-800 flex items-center justify-center">
            <div className="text-center text-white">
              <p className="text-lg">Video would play here</p>
              <p className="text-sm opacity-70">In a real app, this would be the actual video content</p>
            </div>
          </div>
        )}
      </div>
      
      <div className="p-4 bg-gray-800">
        <div className="flex items-center justify-between">
          <Button 
            onClick={() => setIsPlaying(!isPlaying)}
            className="bg-primary hover:bg-primary-700 text-white text-sm font-medium"
          >
            <Play className="mr-2 h-4 w-4" />
            {isPlaying ? 'Pause' : 'Watch'} Explanation
          </Button>
          <div className="flex items-center space-x-2 text-white text-sm">
            <Volume2 className="h-4 w-4 cursor-pointer hover:text-primary" />
            <Captions className="h-4 w-4 cursor-pointer hover:text-primary" />
            <Expand className="h-4 w-4 cursor-pointer hover:text-primary" />
          </div>
        </div>
      </div>
    </div>
  );
}
