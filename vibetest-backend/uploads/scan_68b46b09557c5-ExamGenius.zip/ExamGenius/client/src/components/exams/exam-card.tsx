import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, FileText, Zap, Trophy } from "lucide-react";

interface ExamTemplate {
  id: string;
  title: string;
  description: string;
  duration: number;
  questions: number;
  type: "full" | "subject" | "quick";
  isRecommended: boolean;
}

interface ExamCardProps {
  template: ExamTemplate;
  onStartExam: () => void;
  isLoading: boolean;
}

export default function ExamCard({ template, onStartExam, isLoading }: ExamCardProps) {
  const getCardStyles = () => {
    if (template.isRecommended) {
      return "bg-gradient-to-br from-primary-50 to-blue-50 border-primary-200 border-2";
    }
    return "bg-white border hover:shadow-md transition-shadow";
  };

  const getIcon = () => {
    switch (template.type) {
      case "full":
        return <Clock className="h-6 w-6 text-primary" />;
      case "subject":
        return <FileText className="h-6 w-6 text-blue-600" />;
      case "quick":
        return <Zap className="h-6 w-6 text-green-600" />;
      default:
        return <Trophy className="h-6 w-6 text-gray-600" />;
    }
  };

  const getButtonStyles = () => {
    if (template.isRecommended) {
      return "bg-primary hover:bg-primary-700 text-white";
    }
    return "bg-gray-100 hover:bg-gray-200 text-gray-900";
  };

  const getBadgeText = () => {
    if (template.isRecommended) return "Recommended";
    if (template.type === "subject") return "Subject Test";
    if (template.type === "quick") return "Quick Practice";
    return "Practice Test";
  };

  const getBadgeStyles = () => {
    if (template.isRecommended) return "bg-primary text-white";
    if (template.type === "subject") return "bg-gray-100 text-gray-700";
    if (template.type === "quick") return "bg-success-100 text-success-700";
    return "bg-gray-100 text-gray-700";
  };

  // Mock best score data - would come from API in real app
  const bestScore = template.type === "full" ? "287/400" : template.type === "subject" ? "38/45" : "13/15";
  const difficulty = template.type === "full" ? "Mixed" : template.type === "subject" ? "Mixed" : "Weak areas";

  return (
    <Card className={getCardStyles()}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="bg-primary-100 rounded-lg w-12 h-12 flex items-center justify-center">
            {getIcon()}
          </div>
          <Badge className={getBadgeStyles()}>
            {getBadgeText()}
          </Badge>
        </div>
        
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{template.title}</h3>
        <p className="text-gray-600 mb-4">{template.description}</p>
        
        <div className="space-y-2 mb-6">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Duration:</span>
            <span className="font-medium">{template.duration} minutes</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Questions:</span>
            <span className="font-medium">{template.questions}</span>
          </div>
          {template.type === "full" && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Your Best:</span>
              <span className="font-medium text-success-600">{bestScore}</span>
            </div>
          )}
          {template.type !== "full" && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Focus:</span>
              <span className="font-medium text-warning-600">{difficulty}</span>
            </div>
          )}
        </div>
        
        <Button 
          onClick={onStartExam}
          disabled={isLoading}
          className={`w-full py-3 font-medium transition-colors ${getButtonStyles()}`}
        >
          {isLoading ? "Starting..." : `Start ${template.type === "full" ? "Full Mock Test" : template.type === "subject" ? "Subject Test" : "Quick Practice"}`}
        </Button>
      </CardContent>
    </Card>
  );
}
