import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Subject } from "@shared/schema";
import { Calculator, Book, Atom, FlaskConical, Dna, ChartPie } from "lucide-react";

interface SubjectCardProps {
  subject: Subject;
}

const iconMap: Record<string, any> = {
  calculator: Calculator,
  book: Book,
  atom: Atom,
  flask: FlaskConical,
  dna: Dna,
  'chart-pie': ChartPie,
};

const colorMap: Record<string, string> = {
  blue: 'bg-blue-100 text-blue-600',
  red: 'bg-red-100 text-red-600',
  purple: 'bg-purple-100 text-purple-600',
  green: 'bg-green-100 text-green-600',
  emerald: 'bg-emerald-100 text-emerald-600',
  yellow: 'bg-yellow-100 text-yellow-600',
};

export default function SubjectCard({ subject }: SubjectCardProps) {
  const Icon = iconMap[subject.icon] || Book;
  const iconColorClass = colorMap[subject.color] || 'bg-gray-100 text-gray-600';
  
  // Mock progress data - in a real app this would come from the API
  const progress = Math.floor(Math.random() * 100);
  const questionsCount = Math.floor(Math.random() * 300) + 50;
  
  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'bg-success';
    if (progress >= 60) return 'bg-warning';
    return 'bg-error';
  };

  const getProgressLabel = (progress: number) => {
    if (progress >= 80) return 'text-success-700 bg-success-100';
    if (progress >= 60) return 'text-warning-700 bg-warning-100';
    return 'text-error-700 bg-error-100';
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={`rounded-lg w-12 h-12 flex items-center justify-center ${iconColorClass}`}>
            <Icon className="h-6 w-6" />
          </div>
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getProgressLabel(progress)}`}>
            {progress}% Progress
          </span>
        </div>
        
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{subject.name}</h3>
        <p className="text-gray-600 mb-4">{subject.description}</p>
        
        <div className="bg-gray-100 rounded-full h-2 mb-4">
          <div 
            className={`h-2 rounded-full ${getProgressColor(progress)}`} 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-500">{questionsCount} questions solved</span>
          <Button variant="ghost" className="text-primary hover:text-primary-700 font-medium p-0">
            Continue →
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
