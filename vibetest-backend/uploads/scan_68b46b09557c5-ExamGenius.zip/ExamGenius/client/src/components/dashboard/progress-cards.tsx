import { Card, CardContent } from "@/components/ui/card";
import { Flame, CheckCircle, TrendingUp, Calendar } from "lucide-react";

export default function ProgressCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      <Card className="bg-gradient-to-r from-primary to-primary-600 text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-primary-100 text-sm font-medium">Study Streak</p>
              <p className="text-3xl font-bold">12 days</p>
            </div>
            <Flame className="h-8 w-8" />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Questions Solved</p>
              <p className="text-3xl font-bold text-gray-900">1,247</p>
            </div>
            <CheckCircle className="h-8 w-8 text-success" />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Average Score</p>
              <p className="text-3xl font-bold text-gray-900">78%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-warning" />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Days to JAMB</p>
              <p className="text-3xl font-bold text-error">45</p>
            </div>
            <Calendar className="h-8 w-8 text-error" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
