import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Brain, Star } from "lucide-react";

export default function RecentActivity() {
  const activities = [
    {
      icon: Trophy,
      title: "Mathematics Mock Test",
      description: "Scored 85% - New personal best!",
      time: "2h ago",
      color: "success"
    },
    {
      icon: Brain,
      title: "Physics Question Solved",
      description: "AI explanation for wave mechanics",
      time: "3h ago",
      color: "primary"
    },
    {
      icon: Star,
      title: "Weekly Goal Achieved",
      description: "Completed 50 practice questions",
      time: "1d ago",
      color: "warning"
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'success':
        return 'bg-success-50 border-success text-success-800';
      case 'primary':
        return 'bg-primary-50 border-primary text-primary-800';
      case 'warning':
        return 'bg-warning-50 border-warning text-warning-800';
      default:
        return 'bg-gray-50 border-gray-300 text-gray-800';
    }
  };

  const getIconColorClasses = (color: string) => {
    switch (color) {
      case 'success':
        return 'bg-success-100 text-success';
      case 'primary':
        return 'bg-primary-100 text-primary';
      case 'warning':
        return 'bg-warning-100 text-warning';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-900">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity, index) => (
          <div key={index} className={`flex items-center p-3 rounded-lg ${index === 0 ? getColorClasses(activity.color) : 'hover:bg-gray-50'}`}>
            <div className={`rounded-full w-10 h-10 flex items-center justify-center mr-3 ${getIconColorClasses(activity.color)}`}>
              <activity.icon className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-gray-900">{activity.title}</p>
              <p className="text-sm text-gray-600">{activity.description}</p>
            </div>
            <span className="text-xs text-gray-500">{activity.time}</span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
