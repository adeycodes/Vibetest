import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, Play, Book, ArrowRight } from "lucide-react";

export default function QuickActions() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-900">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Link href="/upload">
          <Button className="w-full bg-primary hover:bg-primary-700 text-white p-4 h-auto justify-between">
            <div className="flex items-center">
              <Camera className="mr-3 h-5 w-5" />
              <span className="font-medium">Snap a Question</span>
            </div>
            <ArrowRight className="h-4 w-4" />
          </Button>
        </Link>
        
        <Link href="/mock-exams">
          <Button variant="outline" className="w-full p-4 h-auto justify-between border hover:bg-gray-50">
            <div className="flex items-center">
              <Play className="mr-3 h-5 w-5 text-warning" />
              <span className="font-medium">Continue Mock Test</span>
            </div>
            <ArrowRight className="h-4 w-4" />
          </Button>
        </Link>
        
        <Link href="/subjects">
          <Button variant="outline" className="w-full p-4 h-auto justify-between border hover:bg-gray-50">
            <div className="flex items-center">
              <Book className="mr-3 h-5 w-5 text-success" />
              <span className="font-medium">Review Weak Topics</span>
            </div>
            <ArrowRight className="h-4 w-4" />
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
