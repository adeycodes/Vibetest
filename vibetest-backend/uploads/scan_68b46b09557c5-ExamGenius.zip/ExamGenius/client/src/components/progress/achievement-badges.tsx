import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserAchievement } from "@shared/schema";
import { Flame, Trophy, Brain, Star, Medal, Crown } from "lucide-react";

interface AchievementBadgesProps {
  achievements: UserAchievement[];
}

export default function AchievementBadges({ achievements }: AchievementBadgesProps) {
  // Mock achievements data with proper structure
  const allAchievements = [
    {
      id: "study-streak",
      title: "Study Streak",
      description: "12 days",
      icon: Flame,
      unlocked: true,
      color: "from-yellow-400 to-yellow-600"
    },
    {
      id: "high-scorer",
      title: "High Scorer",
      description: "85%+ Average",
      icon: Trophy,
      unlocked: true,
      color: "from-green-400 to-green-600"
    },
    {
      id: "quick-learner",
      title: "Quick Learner",
      description: "Fast progress",
      icon: Brain,
      unlocked: true,
      color: "from-blue-400 to-blue-600"
    },
    {
      id: "all-rounder",
      title: "All Rounder",
      description: "All subjects 70%+",
      icon: Star,
      unlocked: true,
      color: "from-purple-400 to-purple-600"
    },
    {
      id: "perfect-score",
      title: "Perfect Score",
      description: "Coming soon...",
      icon: Medal,
      unlocked: false,
      color: "from-gray-300 to-gray-400"
    },
    {
      id: "champion",
      title: "Champion",
      description: "Top 1% scorer",
      icon: Crown,
      unlocked: false,
      color: "from-gray-300 to-gray-400"
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-900 text-center">
          Your Achievements 🏆
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {allAchievements.map((achievement) => {
            const Icon = achievement.icon;
            
            return (
              <div key={achievement.id} className={`text-center ${!achievement.unlocked ? 'opacity-50' : ''}`}>
                <div className={`bg-gradient-to-br ${achievement.color} rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3 shadow-lg ${achievement.unlocked ? '' : 'grayscale'}`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <h4 className={`font-medium text-sm mb-1 ${achievement.unlocked ? 'text-gray-900' : 'text-gray-500'}`}>
                  {achievement.title}
                </h4>
                <p className={`text-xs ${achievement.unlocked ? 'text-gray-600' : 'text-gray-400'}`}>
                  {achievement.description}
                </p>
              </div>
            );
          })}
        </div>
        
        {/* Motivational message */}
        <div className="mt-8 text-center p-4 bg-primary-50 rounded-lg border border-primary-200">
          <p className="text-primary-700 font-medium mb-2">🎯 Keep Going, Champion!</p>
          <p className="text-sm text-primary-600">
            You've unlocked 4 out of 6 achievements. Complete a perfect mock test to unlock your next badge!
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
