import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp } from "lucide-react";

interface ScoreChartProps {
  startingScore: number;
  currentScore: number;
  targetScore: number;
  improvement: number;
}

export default function ScoreChart({ startingScore, currentScore, targetScore, improvement }: ScoreChartProps) {
  // Mock chart data - in a real app this would be actual historical data
  const chartData = [
    { week: "Week 1", score: startingScore },
    { week: "Week 2", score: startingScore + 8 },
    { week: "Week 3", score: startingScore + 15 },
    { week: "Week 4", score: startingScore + 22 },
    { week: "Week 5", score: startingScore + 28 },
    { week: "Week 6", score: startingScore + 35 },
    { week: "Week 7", score: currentScore },
  ];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-semibold text-gray-900">Score Progress</CardTitle>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-sm text-gray-500 hover:text-gray-900">
              7 Days
            </Button>
            <Button variant="ghost" size="sm" className="text-sm text-primary font-medium border-b-2 border-primary">
              30 Days
            </Button>
            <Button variant="ghost" size="sm" className="text-sm text-gray-500 hover:text-gray-900">
              3 Months
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Chart Visualization - Using a simple visual representation */}
        <div className="bg-gradient-to-br from-primary-50 to-blue-50 rounded-lg p-8 mb-6">
          <div className="flex items-center justify-center h-48">
            <div className="text-center text-gray-600">
              <TrendingUp className="h-12 w-12 mb-4 text-primary mx-auto" />
              <p className="font-medium text-lg mb-2">Steady Progress Upward! 📈</p>
              <p className="text-sm">Your scores have improved consistently over the past month</p>
              <div className="mt-4 flex justify-center space-x-8">
                {chartData.slice(-3).map((point, index) => (
                  <div key={index} className="text-center">
                    <div className={`w-3 h-12 bg-primary rounded-full mx-auto mb-2`} 
                         style={{ height: `${(point.score / targetScore) * 48}px` }}></div>
                    <div className="text-xs text-gray-500">{point.week}</div>
                    <div className="text-sm font-medium">{point.score}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-lg font-bold text-gray-900">{startingScore}</div>
            <div className="text-xs text-gray-500">Starting Score</div>
          </div>
          <div>
            <div className="text-lg font-bold text-primary">{currentScore}</div>
            <div className="text-xs text-gray-500">Current Score</div>
          </div>
          <div>
            <div className="text-lg font-bold text-success">+{improvement}</div>
            <div className="text-xs text-gray-500">Improvement</div>
          </div>
          <div>
            <div className="text-lg font-bold text-warning">{targetScore}</div>
            <div className="text-xs text-gray-500">Target Score</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
