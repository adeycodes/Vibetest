import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, X } from "lucide-react";

interface PricingFeature {
  name: string;
  included: boolean;
  highlighted?: boolean;
}

interface PricingCardProps {
  title: string;
  price: string;
  period?: string;
  description: string;
  features: PricingFeature[];
  buttonText: string;
  buttonVariant?: "default" | "outline";
  isPopular?: boolean;
  isCurrent?: boolean;
  onSelect: () => void;
}

export default function PricingCard({
  title,
  price,
  period,
  description,
  features,
  buttonText,
  buttonVariant = "default",
  isPopular = false,
  isCurrent = false,
  onSelect
}: PricingCardProps) {
  return (
    <Card className={`relative ${isPopular ? 'border-2 border-primary' : 'border border-gray-200'}`}>
      {isPopular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <Badge className="bg-primary text-white px-4 py-2">Most Popular</Badge>
        </div>
      )}
      
      <CardHeader className={`text-center ${isPopular ? 'bg-gradient-to-br from-primary-50 to-blue-50' : ''}`}>
        <CardTitle className="text-2xl font-bold text-gray-900 mb-2">{title}</CardTitle>
        <div className="text-4xl font-bold text-gray-900 mb-2">
          {price}
          {period && <span className="text-lg font-normal text-gray-600">/{period}</span>}
        </div>
        <p className="text-gray-600">{description}</p>
      </CardHeader>
      
      <CardContent className="p-6">
        <ul className="space-y-4 mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center">
              {feature.included ? (
                <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
              ) : (
                <X className="h-5 w-5 text-gray-400 mr-3 flex-shrink-0" />
              )}
              <span className={`${feature.included ? 'text-gray-700' : 'text-gray-400'} ${feature.highlighted ? 'font-medium' : ''}`}>
                {feature.name}
              </span>
            </li>
          ))}
        </ul>

        <Button 
          onClick={onSelect}
          variant={buttonVariant}
          className={`w-full py-3 font-semibold transition-colors ${
            isPopular 
              ? 'bg-primary hover:bg-primary-700 text-white shadow-lg' 
              : isCurrent
                ? 'bg-gray-200 hover:bg-gray-300 text-gray-800'
                : 'border-gray-300 hover:border-primary'
          }`}
          disabled={isCurrent}
        >
          {isCurrent ? "Current Plan" : buttonText}
        </Button>
        
        {isPopular && (
          <p className="text-center text-sm text-gray-600 mt-4">
            🎯 Join 47,000+ students achieving 85% success rates
          </p>
        )}
      </CardContent>
    </Card>
  );
}
