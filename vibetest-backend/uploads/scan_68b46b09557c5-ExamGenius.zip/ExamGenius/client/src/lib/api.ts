export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '';

export async function uploadImage(file: File): Promise<string> {
  const formData = new FormData();
  formData.append('image', file);
  
  // TODO: Implement actual image upload to cloud storage
  // For now, return a placeholder URL
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`https://placeholder.image/${file.name}`);
    }, 1000);
  });
}

export async function performOCR(imageUrl: string): Promise<{ text: string; confidence: number }> {
  const response = await fetch('/api/ocr', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ imageUrl }),
  });
  
  if (!response.ok) {
    throw new Error('OCR processing failed');
  }
  
  return response.json();
}

export async function generateAIExplanation(question: string, subject: string) {
  const response = await fetch('/api/ai/explain', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ question, subject }),
  });
  
  if (!response.ok) {
    throw new Error('AI explanation generation failed');
  }
  
  return response.json();
}
