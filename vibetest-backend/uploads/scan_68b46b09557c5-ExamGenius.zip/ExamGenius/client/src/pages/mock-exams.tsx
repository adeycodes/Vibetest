import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ExamCard from "@/components/exams/exam-card";
import { MockExam } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Clock, Target, TrendingUp } from "lucide-react";

const examTypes = [
  { id: "JAMB", name: "JAMB UTME", description: "Complete 4-subject exam" },
  { id: "WAEC", name: "WAEC", description: "West African Examinations" },
  { id: "NECO", name: "NECO", description: "National Examinations Council" },
  { id: "GCE", name: "GCE", description: "General Certificate of Education" }
];

export default function MockExams() {
  const [selectedExamType, setSelectedExamType] = useState("JAMB");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: mockExams, isLoading } = useQuery<MockExam[]>({
    queryKey: ['/api/mock-exams'],
  });

  const createExamMutation = useMutation({
    mutationFn: async (examData: any) => {
      const response = await apiRequest('POST', '/api/mock-exams', examData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mock-exams'] });
      toast({
        title: "Mock exam started! 🚀",
        description: "Good luck with your test. Remember, every question is a step toward success!",
      });
    },
  });

  const handleStartExam = (examType: string, duration: number, questionCount: number) => {
    createExamMutation.mutate({
      examType,
      subjects: ["math", "english", "physics", "chemistry"], // Default subjects
      totalQuestions: questionCount,
    });
  };

  const mockExamTemplates = {
    JAMB: [
      {
        id: "jamb-full",
        title: "JAMB Full Mock Test",
        description: "Complete 4-subject exam with 180 questions in 3 hours",
        duration: 180,
        questions: 180,
        type: "full",
        isRecommended: true,
      },
      {
        id: "jamb-math",
        title: "Mathematics Only",
        description: "Focus on math with 45 carefully selected questions",
        duration: 45,
        questions: 45,
        type: "subject",
        isRecommended: false,
      },
      {
        id: "jamb-quick",
        title: "15-Minute Sprint",
        description: "Quick practice session to sharpen your skills",
        duration: 15,
        questions: 15,
        type: "quick",
        isRecommended: false,
      },
    ],
    WAEC: [
      {
        id: "waec-full",
        title: "WAEC Complete Test",
        description: "Full examination simulation with multiple subjects",
        duration: 240,
        questions: 200,
        type: "full",
        isRecommended: true,
      },
    ],
    NECO: [
      {
        id: "neco-full",
        title: "NECO Complete Test",
        description: "Comprehensive NECO examination practice",
        duration: 210,
        questions: 180,
        type: "full",
        isRecommended: true,
      },
    ],
    GCE: [
      {
        id: "gce-full",
        title: "GCE Complete Test",
        description: "General Certificate of Education practice test",
        duration: 180,
        questions: 150,
        type: "full",
        isRecommended: true,
      },
    ],
  };

  // Calculate recent performance stats
  const recentPerformance = {
    latestScore: 287,
    averageAccuracy: 78,
    testsCompleted: 47,
    improvement: 23,
    accuracyImprovement: 12,
    targetTests: 60,
  };

  if (isLoading) {
    return (
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Practice with Real Exam Conditions</h2>
            <div className="animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto"></div>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-gray-200 rounded-xl h-64 animate-pulse"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Practice with Real Exam Conditions</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Take timed mock exams that simulate actual WAEC, JAMB, NECO, and GCE conditions. Build your confidence and exam stamina.
          </p>
        </div>

        {/* Exam Type Selector */}
        <Tabs value={selectedExamType} onValueChange={setSelectedExamType} className="mb-12">
          <TabsList className="grid w-full grid-cols-4 max-w-2xl mx-auto">
            {examTypes.map((exam) => (
              <TabsTrigger key={exam.id} value={exam.id} className="font-medium">
                {exam.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {examTypes.map((examType) => (
            <TabsContent key={examType.id} value={examType.id}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {mockExamTemplates[examType.id as keyof typeof mockExamTemplates]?.map((template) => (
                  <ExamCard
                    key={template.id}
                    template={template}
                    onStartExam={() => handleStartExam(examType.id, template.duration, template.questions)}
                    isLoading={createExamMutation.isPending}
                  />
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* Recent Performance */}
        <Card className="bg-gray-50">
          <CardContent className="p-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">Your Recent Performance 📊</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg p-6 text-center">
                <div className="flex items-center justify-center mb-2">
                  <Target className="h-6 w-6 text-primary mr-2" />
                  <div className="text-2xl font-bold text-primary">{recentPerformance.latestScore}</div>
                </div>
                <div className="text-sm text-gray-600 mb-2">Latest JAMB Score</div>
                <div className="text-xs text-success-600 flex items-center justify-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +{recentPerformance.improvement} points improvement
                </div>
              </div>
              
              <div className="bg-white rounded-lg p-6 text-center">
                <div className="flex items-center justify-center mb-2">
                  <TrendingUp className="h-6 w-6 text-warning mr-2" />
                  <div className="text-2xl font-bold text-warning">{recentPerformance.averageAccuracy}%</div>
                </div>
                <div className="text-sm text-gray-600 mb-2">Average Accuracy</div>
                <div className="text-xs text-success-600 flex items-center justify-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +{recentPerformance.accuracyImprovement}% this month
                </div>
              </div>
              
              <div className="bg-white rounded-lg p-6 text-center">
                <div className="flex items-center justify-center mb-2">
                  <Clock className="h-6 w-6 text-success mr-2" />
                  <div className="text-2xl font-bold text-success">{recentPerformance.testsCompleted}</div>
                </div>
                <div className="text-sm text-gray-600 mb-2">Tests Completed</div>
                <div className="text-xs text-primary">Target: {recentPerformance.targetTests} by exam</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
