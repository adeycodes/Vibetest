import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ScoreChart from "@/components/progress/score-chart";
import AchievementBadges from "@/components/progress/achievement-badges";
import { UserProgress, UserAchievement } from "@shared/schema";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, Target, Award, Lightbulb } from "lucide-react";

export default function ProgressPage() {
  const { data: userProgress, isLoading: progressLoading } = useQuery<UserProgress[]>({
    queryKey: ['/api/progress'],
  });

  const { data: achievements, isLoading: achievementsLoading } = useQuery<UserAchievement[]>({
    queryKey: ['/api/achievements'],
  });

  // Mock data for comprehensive progress tracking
  const progressStats = {
    startingScore: 245,
    currentScore: 287,
    improvement: 42,
    targetScore: 320,
    progressToTarget: ((287 - 245) / (320 - 245)) * 100,
  };

  const subjectPerformance = [
    { subject: "Mathematics", percentage: 85, color: "success" },
    { subject: "English", percentage: 78, color: "success" },
    { subject: "Physics", percentage: 65, color: "warning" },
    { subject: "Chemistry", percentage: 52, color: "error" },
  ];

  const studyInsights = [
    {
      type: "strength",
      subject: "Mathematics",
      message: "Excellent work on algebra! You've mastered 9 out of 10 topics.",
      action: "Try advanced calculus problems to challenge yourself further."
    },
    {
      type: "improvement",
      subject: "Chemistry",
      message: "Focus needed on organic reactions and chemical bonding.",
      action: "Complete 15 more practice questions on organic chemistry this week."
    },
    {
      type: "tip",
      subject: "Physics",
      message: "Wave mechanics showing improvement - keep practicing!",
      action: "Review electromagnetic waves and sound wave problems."
    }
  ];

  if (progressLoading || achievementsLoading) {
    return (
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Track Your Success Journey 📈</h2>
            <div className="animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto"></div>
            </div>
          </div>
          <div className="space-y-8">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-gray-200 rounded-xl h-64 animate-pulse"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Track Your Success Journey 📈</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Monitor your progress, identify strengths and weaknesses, and see your improvement over time
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Score Progress Chart */}
          <div className="lg:col-span-2">
            <ScoreChart 
              startingScore={progressStats.startingScore}
              currentScore={progressStats.currentScore}
              targetScore={progressStats.targetScore}
              improvement={progressStats.improvement}
            />
          </div>

          {/* Subject Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl font-semibold text-gray-900">Subject Performance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {subjectPerformance.map((subject) => (
                <div key={subject.subject}>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700">{subject.subject}</span>
                    <span className={`text-sm font-medium text-${subject.color}-600`}>{subject.percentage}%</span>
                  </div>
                  <Progress 
                    value={subject.percentage} 
                    className={`h-2 bg-gray-200`}
                  />
                </div>
              ))}
              
              <Card className="bg-warning-50 border-warning-200 mt-6">
                <CardContent className="p-4">
                  <div className="flex items-start">
                    <Lightbulb className="h-5 w-5 text-warning-600 mt-1 mr-3 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium text-warning-800 mb-1">Improvement Tip</h4>
                      <p className="text-sm text-warning-700">
                        Focus on Chemistry organic reactions. Try 15 more practice questions this week.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </div>

        {/* Progress Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card>
            <CardContent className="p-6 text-center">
              <Target className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold text-primary mb-1">{progressStats.currentScore}</div>
              <div className="text-sm text-gray-600">Current Score</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-8 w-8 text-success mx-auto mb-2" />
              <div className="text-2xl font-bold text-success mb-1">+{progressStats.improvement}</div>
              <div className="text-sm text-gray-600">Points Improved</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Award className="h-8 w-8 text-warning mx-auto mb-2" />
              <div className="text-2xl font-bold text-warning mb-1">{Math.round(progressStats.progressToTarget)}%</div>
              <div className="text-sm text-gray-600">To Target</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Target className="h-8 w-8 text-gray-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900 mb-1">{progressStats.targetScore}</div>
              <div className="text-sm text-gray-600">Target Score</div>
            </CardContent>
          </Card>
        </div>

        {/* Study Insights */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-gray-900">📚 Study Insights & Recommendations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {studyInsights.map((insight, index) => (
              <div 
                key={index} 
                className={`p-4 rounded-lg border-l-4 ${
                  insight.type === 'strength' ? 'bg-success-50 border-success-400' :
                  insight.type === 'improvement' ? 'bg-warning-50 border-warning-400' :
                  'bg-blue-50 border-blue-400'
                }`}
              >
                <div className="flex items-start">
                  <div className={`rounded-full w-8 h-8 flex items-center justify-center mr-3 ${
                    insight.type === 'strength' ? 'bg-success text-white' :
                    insight.type === 'improvement' ? 'bg-warning text-white' :
                    'bg-blue-500 text-white'
                  }`}>
                    {insight.type === 'strength' ? '✓' : insight.type === 'improvement' ? '!' : '💡'}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">{insight.subject}</h4>
                    <p className="text-gray-700 text-sm mb-2">{insight.message}</p>
                    <p className="text-gray-600 text-xs italic">{insight.action}</p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Achievement Badges */}
        <AchievementBadges achievements={achievements || []} />
      </div>
    </div>
  );
}
