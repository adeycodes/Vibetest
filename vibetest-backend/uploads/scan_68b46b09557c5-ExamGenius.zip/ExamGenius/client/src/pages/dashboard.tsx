import { useAuth } from "@/hooks/use-auth";
import ProgressCards from "@/components/dashboard/progress-cards";
import QuickActions from "@/components/dashboard/quick-actions";
import RecentActivity from "@/components/dashboard/recent-activity";

export default function Dashboard() {
  const { user } = useAuth();

  if (!user) return null;

  return (
    <div className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user.firstName}! 🎯
          </h2>
          <p className="text-gray-600">You're on track for success. Keep up the great work!</p>
        </div>

        <ProgressCards />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-12">
          <QuickActions />
          <RecentActivity />
        </div>
      </div>
    </div>
  );
}
