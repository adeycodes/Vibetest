import { useParams } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import SolutionSteps from "@/components/explanation/solution-steps";
import VideoPlayer from "@/components/explanation/video-player";
import { Bookmark, Share, RotateCcw, Bot } from "lucide-react";

export default function AIExplanation() {
  const { id } = useParams();

  // Mock data - in real app this would be fetched based on the ID
  const explanation = {
    question: "Solve for x: 2x² + 5x - 3 = 0",
    subject: "Mathematics",
    topic: "Quadratic Equations",
    confidence: 98,
    steps: [
      {
        stepNumber: 1,
        title: "Identify the equation type",
        description: "This is a quadratic equation in the form ax² + bx + c = 0, where a = 2, b = 5, c = -3",
        color: "blue"
      },
      {
        stepNumber: 2,
        title: "Apply the quadratic formula",
        description: "x = (-b ± √(b² - 4ac)) / 2a\nx = (-5 ± √(25 + 24)) / 4",
        color: "green"
      },
      {
        stepNumber: 3,
        title: "Simplify the discriminant",
        description: "√49 = 7\nx = (-5 ± 7) / 4",
        color: "yellow"
      },
      {
        stepNumber: 4,
        title: "Calculate both solutions",
        description: "x₁ = (-5 + 7) / 4 = 2/4 = 1/2\nx₂ = (-5 - 7) / 4 = -12/4 = -3",
        color: "purple"
      }
    ],
    finalAnswer: "x = 1/2 or x = -3",
    explanation: "This quadratic equation has two real solutions. The positive solution x = 1/2 and negative solution x = -3 both satisfy the original equation."
  };

  return (
    <div className="py-16 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card className="shadow-lg overflow-hidden">
          <div className="p-6 bg-gradient-to-r from-primary to-primary-600 text-white">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold mb-2">AI Solution Explanation</h2>
                <p className="text-primary-100">{explanation.subject} • {explanation.topic}</p>
              </div>
              <div className="bg-white bg-opacity-20 rounded-lg p-3">
                <Bot className="h-8 w-8" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-8">
            {/* Question Side */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Question</h3>
              <div className="bg-gray-50 rounded-xl p-6 mb-6">
                <div className="bg-white rounded-lg p-8 border-2 border-dashed border-gray-200 text-center mb-4">
                  <p className="text-gray-900 font-medium">{explanation.question}</p>
                </div>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>Detected: {explanation.subject} Question</span>
                  <Badge className="bg-success-100 text-success-700">
                    {explanation.confidence}% Confidence
                  </Badge>
                </div>
              </div>

              <VideoPlayer />
            </div>

            {/* Solution Side */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Step-by-Step Solution</h3>
              
              <SolutionSteps steps={explanation.steps} finalAnswer={explanation.finalAnswer} />

              {/* Action Buttons */}
              <div className="mt-8 flex flex-col sm:flex-row gap-3">
                <Button className="bg-primary hover:bg-primary-700 text-white flex-1">
                  <Bookmark className="mr-2 h-4 w-4" />
                  Save Solution
                </Button>
                <Button variant="outline" className="flex-1">
                  <Share className="mr-2 h-4 w-4" />
                  Share
                </Button>
                <Button variant="outline" className="flex-1">
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Try Similar
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
