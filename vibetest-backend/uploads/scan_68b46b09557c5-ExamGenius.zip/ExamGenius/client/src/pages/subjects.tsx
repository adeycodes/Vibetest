import { useQuery } from "@tanstack/react-query";
import SubjectCard from "@/components/subjects/subject-card";
import { Subject } from "@shared/schema";

export default function Subjects() {
  const { data: subjects, isLoading } = useQuery<Subject[]>({
    queryKey: ['/api/subjects'],
  });

  if (isLoading) {
    return (
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Master Every Subject</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Loading your personalized subject dashboard...
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-sm border animate-pulse h-48"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Master Every Subject</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Comprehensive coverage of all WAEC, JAMB, NECO, and GCE subjects with AI-powered learning paths
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects?.map((subject) => (
            <SubjectCard key={subject.id} subject={subject} />
          ))}
        </div>
      </div>
    </div>
  );
}
