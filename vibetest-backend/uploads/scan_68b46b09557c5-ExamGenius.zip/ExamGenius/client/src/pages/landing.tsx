import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Brain, Camera, Trophy, Flame, CheckCircle, TrendingUp, Calendar, Shield } from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: Brain,
      title: "AI-Powered Explanations",
      description: "Get instant, personalized explanations for any question"
    },
    {
      icon: Camera,
      title: "Snap & Learn",
      description: "Photo any question and get detailed video explanations"
    },
    {
      icon: Trophy,
      title: "85% Success Rate",
      description: "Proven results with thousands of successful students"
    }
  ];

  const achievements = [
    { number: "50,000+", label: "Nigerian Students" },
    { number: "85%", label: "Success Rate" },
    { number: "1M+", label: "Questions Solved" },
    { number: "24/7", label: "AI Support" }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-50 to-blue-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Master Your <span className="text-primary">WAEC, JAMB & NECO</span> 
              <br />with AI-Powered Learning
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Join over 50,000 Nigerian students achieving 85% success rates with personalized AI tutoring, 
              instant explanations, and comprehensive exam preparation.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link href="/register">
                <Button size="lg" className="bg-primary hover:bg-primary-700 text-white px-8 py-4 text-lg font-semibold shadow-lg">
                  Start Free Trial
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="border-2 border-primary text-primary hover:bg-primary hover:text-white px-8 py-4 text-lg font-semibold">
                Watch Demo
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-4xl mx-auto">
              {features.map((feature, index) => (
                <div key={index} className="text-center">
                  <div className="bg-success-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="h-8 w-8 text-success" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Trusted by Nigerian Students</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our proven track record speaks for itself. Join thousands of successful students who achieved their exam goals with PrepNaija.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {achievements.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Everything You Need to Succeed</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Comprehensive exam preparation tools designed specifically for Nigerian students and their unique challenges.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="bg-primary-100 rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                  <Camera className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Instant Question Solving</h3>
                <p className="text-gray-600">Snap any question with your phone and get step-by-step AI explanations in seconds.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="bg-success-100 rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                  <Brain className="h-6 w-6 text-success" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Personalized AI Tutor</h3>
                <p className="text-gray-600">Get explanations tailored to your learning style and academic level.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="bg-warning-100 rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                  <TrendingUp className="h-6 w-6 text-warning" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Progress Tracking</h3>
                <p className="text-gray-600">Monitor your improvement with detailed analytics and performance insights.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="bg-error-100 rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                  <Calendar className="h-6 w-6 text-error" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Mock Exams</h3>
                <p className="text-gray-600">Practice with realistic exam conditions and time limits for all subjects.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="bg-purple-100 rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                  <Trophy className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Achievement System</h3>
                <p className="text-gray-600">Stay motivated with badges, streaks, and celebration milestones.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="bg-blue-100 rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">All Exam Types</h3>
                <p className="text-gray-600">Comprehensive coverage for WAEC, JAMB, NECO, and GCE examinations.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Success Plan</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Affordable pricing designed for Nigerian students. Start free and upgrade when you're ready to excel.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Free Plan */}
            <Card className="border-2 border-gray-200">
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Free Starter</h3>
                  <div className="text-4xl font-bold text-gray-900 mb-2">₦0</div>
                  <p className="text-gray-600">Perfect for getting started</p>
                </div>

                <ul className="space-y-4 mb-8">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700">5 AI explanations per day</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700">Basic progress tracking</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700">1 mock test per week</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700">Community access</span>
                  </li>
                </ul>

                <Link href="/register">
                  <Button variant="outline" className="w-full">Get Started Free</Button>
                </Link>
              </CardContent>
            </Card>

            {/* Pro Plan */}
            <Card className="border-2 border-primary relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-primary text-white px-4 py-2 rounded-full text-sm font-medium">Most Popular</span>
              </div>
              
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Pro Success</h3>
                  <div className="text-4xl font-bold text-primary mb-2">₦5,000</div>
                  <p className="text-gray-600">per month • 85% success guarantee</p>
                </div>

                <ul className="space-y-4 mb-8">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700 font-medium">Unlimited AI explanations</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700 font-medium">HD video explanations</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700 font-medium">Unlimited mock tests</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700 font-medium">Advanced analytics</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700 font-medium">Priority support</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-success mr-3" />
                    <span className="text-gray-700 font-medium">Personalized study plan</span>
                  </li>
                </ul>

                <Link href="/register">
                  <Button className="w-full bg-primary hover:bg-primary-700">
                    Upgrade to Pro
                  </Button>
                </Link>
                
                <p className="text-center text-sm text-gray-600 mt-4">
                  🎯 Join 47,000+ students achieving 85% success rates
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Money Back Guarantee */}
          <div className="mt-12 text-center">
            <Card className="bg-success-50 border-success-200 max-w-2xl mx-auto">
              <CardContent className="p-6">
                <div className="flex items-center justify-center mb-4">
                  <Shield className="h-8 w-8 text-success mr-3" />
                  <h4 className="text-lg font-semibold text-success-800">30-Day Money-Back Guarantee</h4>
                </div>
                <p className="text-success-700">
                  If you don't see improvement in your scores within 30 days, we'll refund your money completely. No questions asked.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Transform Your Exam Results?
          </h2>
          <p className="text-xl text-primary-100 mb-8 max-w-2xl mx-auto">
            Join thousands of Nigerian students who've already started their success journey with PrepNaija.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/register">
              <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-gray-100 px-8 py-4 text-lg font-semibold">
                Start Your Free Trial Today
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-4 text-lg font-semibold">
              Learn More
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
