import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { FileText, Upload, Eye, Download, Plus, Filter, BookOpen, Calendar, GraduationCap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface PastQuestionPaper {
  id: string;
  examType: string;
  subjectId: string;
  year: number;
  title: string;
  pdfUrl: string;
  fileName: string;
  fileSize?: number;
  totalQuestions?: number;
  isProcessed: boolean;
  uploadedAt: Date;
}

interface Subject {
  id: string;
  name: string;
  examTypes: string[];
}

export default function PastQuestions() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedExamType, setSelectedExamType] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<string>('');
  const [selectedYear, setSelectedYear] = useState<string>('');
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  
  // Generate years from 2015 to 2025
  const years = Array.from({ length: 11 }, (_, i) => 2015 + i);
  const examTypes = ['WAEC', 'JAMB', 'NECO', 'GCE'];

  // Fetch subjects
  const { data: subjects = [] } = useQuery<Subject[]>({
    queryKey: ['/api/subjects'],
  });

  // Fetch past question papers with filters
  const { data: papers = [], isLoading } = useQuery<PastQuestionPaper[]>({
    queryKey: ['/api/past-question-papers', selectedExamType, selectedSubject, selectedYear],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedExamType) params.append('examType', selectedExamType);
      if (selectedSubject) params.append('subjectId', selectedSubject);
      if (selectedYear) params.append('year', selectedYear);
      
      const response = await fetch(`/api/past-question-papers?${params.toString()}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch past question papers');
      }
      
      return response.json();
    },
  });

  // Upload mutation
  const uploadMutation = useMutation({
    mutationFn: async (data: {
      examType: string;
      subjectId: string;
      year: number;
      title: string;
      file: File;
    }) => {
      // In a real app, this would upload to cloud storage and return the URL
      const fakeUrl = `https://storage.prepnaija.com/papers/${data.file.name}`;
      
      const response = await fetch('/api/past-question-papers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          examType: data.examType,
          subjectId: data.subjectId,
          year: data.year,
          title: data.title,
          pdfUrl: fakeUrl,
          fileName: data.file.name,
          fileSize: data.file.size,
          isProcessed: false,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to upload past question paper');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/past-question-papers'] });
      setIsUploadDialogOpen(false);
      toast({
        title: "Upload Successful",
        description: "Past question paper uploaded successfully! Questions will be processed shortly.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload past question paper",
        variant: "destructive",
      });
    },
  });

  const handleUpload = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const file = formData.get('file') as File;
    
    if (!file || file.type !== 'application/pdf') {
      toast({
        title: "Invalid File",
        description: "Please select a PDF file",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate({
      examType: formData.get('examType') as string,
      subjectId: formData.get('subjectId') as string,
      year: parseInt(formData.get('year') as string),
      title: formData.get('title') as string,
      file,
    });
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return 'Unknown size';
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  const getExamTypeColor = (examType: string) => {
    const colors = {
      WAEC: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      JAMB: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      NECO: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      GCE: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
    };
    return colors[examType as keyof typeof colors] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-[400px]">
          <CardHeader className="text-center">
            <GraduationCap className="h-12 w-12 mx-auto mb-4 text-primary" />
            <CardTitle>Access Restricted</CardTitle>
            <CardDescription>Please log in to access past questions</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Past Questions Bank
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Access official past questions from 2015-2025 for all exam bodies
          </p>
        </div>
        
        <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Upload PDF
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Upload Past Question Paper</DialogTitle>
              <DialogDescription>
                Upload PDF files containing past questions from 2015-2025
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleUpload} className="space-y-4">
              <div className="grid w-full gap-1.5">
                <Label htmlFor="examType">Exam Body</Label>
                <Select name="examType" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select exam body" />
                  </SelectTrigger>
                  <SelectContent>
                    {examTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid w-full gap-1.5">
                <Label htmlFor="subjectId">Subject</Label>
                <Select name="subjectId" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subject) => (
                      <SelectItem key={subject.id} value={subject.id}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid w-full gap-1.5">
                <Label htmlFor="year">Year</Label>
                <Select name="year" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select year" />
                  </SelectTrigger>
                  <SelectContent>
                    {years.reverse().map((year) => (
                      <SelectItem key={year} value={year.toString()}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid w-full gap-1.5">
                <Label htmlFor="title">Title</Label>
                <Input
                  name="title"
                  placeholder="e.g., WAEC Mathematics 2020"
                  required
                />
              </div>

              <div className="grid w-full gap-1.5">
                <Label htmlFor="file">PDF File</Label>
                <Input
                  name="file"
                  type="file"
                  accept=".pdf"
                  required
                />
              </div>

              <Button 
                type="submit" 
                className="w-full" 
                disabled={uploadMutation.isPending}
              >
                {uploadMutation.isPending ? (
                  <>
                    <Upload className="h-4 w-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload PDF
                  </>
                )}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters Section */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filter Past Questions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Exam Body</Label>
              <Select value={selectedExamType} onValueChange={setSelectedExamType}>
                <SelectTrigger>
                  <SelectValue placeholder="All exam bodies" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All exam bodies</SelectItem>
                  {examTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Subject</Label>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger>
                  <SelectValue placeholder="All subjects" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All subjects</SelectItem>
                  {subjects.map((subject) => (
                    <SelectItem key={subject.id} value={subject.id}>
                      {subject.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Year</Label>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger>
                  <SelectValue placeholder="All years" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All years</SelectItem>
                  {years.map((year) => (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Papers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
                <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2" />
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded" />
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-5/6" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : papers.length === 0 ? (
          <div className="col-span-full">
            <Card>
              <CardContent className="text-center py-12">
                <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  No Past Questions Found
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {selectedExamType || selectedSubject || selectedYear
                    ? "No past questions match your current filters."
                    : "No past questions have been uploaded yet."}
                </p>
                <Button onClick={() => setIsUploadDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Upload First PDF
                </Button>
              </CardContent>
            </Card>
          </div>
        ) : (
          papers.map((paper) => {
            const subject = subjects.find(s => s.id === paper.subjectId);
            
            return (
              <Card key={paper.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-1">{paper.title}</CardTitle>
                      <CardDescription className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        {paper.year}
                      </CardDescription>
                    </div>
                    <Badge className={getExamTypeColor(paper.examType)}>
                      {paper.examType}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-2 mb-1">
                      <BookOpen className="h-4 w-4" />
                      {subject?.name || 'Unknown Subject'}
                    </div>
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      {formatFileSize(paper.fileSize)}
                      {paper.totalQuestions && (
                        <span className="ml-2">• {paper.totalQuestions} questions</span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge 
                      variant={paper.isProcessed ? "default" : "secondary"}
                      className="text-xs"
                    >
                      {paper.isProcessed ? "Processed" : "Processing..."}
                    </Badge>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => window.open(paper.pdfUrl, '_blank')}
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = paper.pdfUrl;
                        link.download = paper.fileName;
                        link.click();
                      }}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Statistics Card */}
      {papers.length > 0 && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Collection Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-primary">{papers.length}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Total Papers</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-primary">
                  {papers.reduce((sum, p) => sum + (p.totalQuestions || 0), 0)}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Total Questions</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-primary">
                  {new Set(papers.map(p => p.year)).size}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Years Covered</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-primary">
                  {papers.filter(p => p.isProcessed).length}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Processed</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}