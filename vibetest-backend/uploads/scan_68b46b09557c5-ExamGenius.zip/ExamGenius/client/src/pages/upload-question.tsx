import { useState } from "react";
import { useLocation } from "wouter";
import UploadArea from "@/components/upload/upload-area";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { uploadImage, performOCR, generateAIExplanation } from "@/lib/api";

export default function UploadQuestion() {
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleFileUpload = async (file: File) => {
    setIsProcessing(true);
    
    try {
      // Upload image
      toast({
        title: "Processing your question... 📸",
        description: "This might take a few moments while we analyze the image.",
      });
      
      const imageUrl = await uploadImage(file);
      
      // Perform OCR
      const ocrResult = await performOCR(imageUrl);
      
      // Generate AI explanation
      const explanation = await generateAIExplanation(ocrResult.text, "Mathematics");
      
      toast({
        title: "Question processed successfully! ✨",
        description: "Your AI explanation is ready. Redirecting you now...",
      });
      
      // In a real app, you would save the explanation and navigate to it
      setTimeout(() => {
        setLocation('/explanation/sample-id');
      }, 1500);
      
    } catch (error: any) {
      toast({
        title: "Processing failed",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const sampleQuestions = [
    {
      subject: "Mathematics",
      title: "Quadratic Equations",
      description: "Solve for x in the given equation...",
    },
    {
      subject: "Physics",
      title: "Wave Mechanics",
      description: "Calculate the frequency of the wave...",
    },
    {
      subject: "English",
      title: "Comprehension",
      description: "Read the passage and answer...",
    },
  ];

  return (
    <div className="py-16 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Got a Tough Question? 📸</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Simply snap a photo or upload an image of any question and get instant AI-powered explanations with step-by-step solutions
          </p>
        </div>

        <div className="mb-8">
          <UploadArea onFileUpload={handleFileUpload} isProcessing={isProcessing} />
        </div>

        {/* Sample Questions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {sampleQuestions.map((question, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="bg-gray-100 rounded-lg h-32 mb-4 flex items-center justify-center">
                  <span className="text-gray-500 text-sm">Sample {question.subject} Question</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">{question.title}</h4>
                <p className="text-sm text-gray-600 mb-3">{question.description}</p>
                <Button variant="ghost" className="text-primary hover:text-primary-700 text-sm font-medium p-0">
                  Try This Sample →
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
