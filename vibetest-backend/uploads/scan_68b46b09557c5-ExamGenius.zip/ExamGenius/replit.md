# PrepNaija - AI-Powered Exam Preparation Platform

## Overview

PrepNaija is a comprehensive exam preparation platform designed for Nigerian students studying for WAEC, JAMB, NECO, and GCE examinations. The platform leverages AI technology to provide personalized learning experiences, including instant question explanations, mock examinations, and progress tracking. Built as a full-stack web application with React frontend and Express backend, it offers features like photo-based question capture, AI-powered explanations, mock exam simulations, and detailed progress analytics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built using React with TypeScript, utilizing a modern component-based architecture. The application uses Wouter for lightweight routing and TanStack Query for efficient server state management. The UI is built with shadcn/ui components based on Radix UI primitives, styled with Tailwind CSS using CSS variables for theming. The application follows a modular structure with separate directories for pages, components, hooks, and utilities, implementing proper separation of concerns.

### Backend Architecture
The server is built with Express.js using TypeScript, implementing a RESTful API architecture. The application uses an in-memory storage pattern with interfaces defining the data access layer, allowing for easy transition to database implementations. Authentication is handled using JWT tokens with bcrypt for password hashing. The server includes middleware for request logging, error handling, and token verification. API routes are organized by functionality (auth, subjects, questions, mock exams, progress tracking).

### Data Storage Solutions
The application is configured to use PostgreSQL as the primary database with Drizzle ORM for type-safe database operations. The schema defines comprehensive entities including users, subjects, questions, user progress, mock exams, AI explanations, and user achievements. Database credentials are managed through environment variables, with Drizzle Kit configured for schema migrations. The current implementation uses an in-memory storage pattern for development, with interfaces designed to seamlessly transition to the PostgreSQL implementation.

### Authentication and Authorization
User authentication is implemented using JWT (JSON Web Tokens) with a custom auth provider managing login state across the application. Password security is handled through bcrypt hashing, and protected routes are secured using authentication middleware. The frontend maintains auth state through React Context and localStorage for token persistence. User sessions include user profile information and role-based access patterns.

### Component Architecture
The UI follows a design system approach using shadcn/ui components with consistent theming through CSS custom properties. Components are organized into logical groupings (dashboard, subjects, exams, progress, layout) with reusable UI primitives. The application implements responsive design patterns optimized for mobile and desktop experiences. State management combines local component state, React Query for server state, and Context for global auth state.

## External Dependencies

### Database and ORM
- **PostgreSQL**: Primary database using Neon serverless PostgreSQL
- **Drizzle ORM**: Type-safe database operations and schema management
- **Drizzle Kit**: Database migrations and schema tooling

### Frontend Dependencies
- **React 18**: Core frontend framework with hooks and concurrent features
- **TypeScript**: Type safety and enhanced developer experience
- **Vite**: Build tool and development server with hot module replacement
- **Wouter**: Lightweight client-side routing
- **TanStack Query**: Server state management and caching
- **Tailwind CSS**: Utility-first CSS framework for styling

### UI and Design System
- **Radix UI**: Accessible, unstyled UI primitives for complex components
- **shadcn/ui**: Pre-built component library based on Radix UI
- **Lucide React**: Icon library for consistent iconography
- **class-variance-authority**: Utility for creating variant-based component APIs

### Backend Dependencies
- **Express.js**: Web application framework for Node.js
- **JWT**: JSON Web Token implementation for authentication
- **bcryptjs**: Password hashing and verification
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### Development and Build Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **TSX**: TypeScript execution engine for development
- **PostCSS**: CSS processing with Tailwind CSS integration
- **Autoprefixer**: CSS vendor prefix automation

### Third-Party Integrations
- **Image Upload Service**: Placeholder implementation for cloud storage integration
- **OCR Service**: Optical Character Recognition for question text extraction
- **AI Explanation Service**: AI-powered question explanation generation
- **Replit Development Tools**: Development environment integration and error handling