import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  isPro: boolean("is_pro").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const subjects = pgTable("subjects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
  description: text("description"),
});

export const questions = pgTable("questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  subjectId: varchar("subject_id").references(() => subjects.id),
  examType: text("exam_type").notNull(), // WAEC, JAMB, NECO, GCE
  difficulty: text("difficulty").notNull(), // easy, medium, hard
  correctAnswer: text("correct_answer").notNull(),
  options: jsonb("options"), // For multiple choice
  explanation: text("explanation"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userProgress = pgTable("user_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  subjectId: varchar("subject_id").references(() => subjects.id).notNull(),
  questionsAnswered: integer("questions_answered").default(0),
  questionsCorrect: integer("questions_correct").default(0),
  averageScore: decimal("average_score", { precision: 5, scale: 2 }).default('0'),
  lastStudied: timestamp("last_studied"),
});

export const mockExams = pgTable("mock_exams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  examType: text("exam_type").notNull(),
  subjects: jsonb("subjects").notNull(), // Array of subject IDs
  score: integer("score"),
  totalQuestions: integer("total_questions").notNull(),
  timeSpent: integer("time_spent"), // in seconds
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const aiExplanations = pgTable("ai_explanations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  questionId: varchar("question_id").references(() => questions.id),
  uploadedImageUrl: text("uploaded_image_url"),
  ocrText: text("ocr_text"),
  explanation: text("explanation").notNull(),
  videoUrl: text("video_url"),
  steps: jsonb("steps"), // Step-by-step solution
  createdAt: timestamp("created_at").defaultNow(),
});

export const userAchievements = pgTable("user_achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  achievementType: text("achievement_type").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  icon: text("icon").notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

export const syllabi = pgTable("syllabi", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  examType: text("exam_type").notNull(), // WAEC, JAMB, NECO, GCE
  subjectId: varchar("subject_id").references(() => subjects.id).notNull(),
  year: integer("year").notNull(),
  topics: jsonb("topics").notNull(), // Array of topic objects with subtopics
  objectives: jsonb("objectives"), // Learning objectives for each topic
  createdAt: timestamp("created_at").defaultNow(),
});

export const pastQuestionPapers = pgTable("past_question_papers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  examType: text("exam_type").notNull(), // WAEC, JAMB, NECO, GCE
  subjectId: varchar("subject_id").references(() => subjects.id).notNull(),
  year: integer("year").notNull(),
  title: text("title").notNull(), // e.g., "WAEC Mathematics 2020"
  pdfUrl: text("pdf_url").notNull(), // URL to stored PDF file
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size"), // File size in bytes
  totalQuestions: integer("total_questions"),
  isProcessed: boolean("is_processed").default(false), // Whether questions have been extracted
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const pastQuestions = pgTable("past_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  paperId: varchar("paper_id").references(() => pastQuestionPapers.id).notNull(),
  examType: text("exam_type").notNull(), // WAEC, JAMB, NECO, GCE
  subjectId: varchar("subject_id").references(() => subjects.id).notNull(),
  year: integer("year").notNull(),
  questionNumber: integer("question_number").notNull(),
  content: text("content").notNull(),
  options: jsonb("options"), // For multiple choice questions
  correctAnswer: text("correct_answer").notNull(),
  explanation: text("explanation"),
  topic: text("topic"), // Topic this question covers
  difficulty: text("difficulty").default('medium'), // easy, medium, hard
  imageUrl: text("image_url"), // For questions with diagrams
  pageNumber: integer("page_number"), // Page in original PDF
  createdAt: timestamp("created_at").defaultNow(),
});

export const syllabusProgress = pgTable("syllabus_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  syllabusId: varchar("syllabus_id").references(() => syllabi.id).notNull(),
  topicId: text("topic_id").notNull(), // Reference to topic within syllabus
  isCompleted: boolean("is_completed").default(false),
  masteryLevel: integer("mastery_level").default(0), // 0-100 proficiency score
  lastStudied: timestamp("last_studied"),
  questionsAnswered: integer("questions_answered").default(0),
  questionsCorrect: integer("questions_correct").default(0),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertSubjectSchema = createInsertSchema(subjects).omit({
  id: true,
});

export const insertQuestionSchema = createInsertSchema(questions).omit({
  id: true,
  createdAt: true,
});

export const insertUserProgressSchema = createInsertSchema(userProgress).omit({
  id: true,
});

export const insertMockExamSchema = createInsertSchema(mockExams).omit({
  id: true,
  createdAt: true,
});

export const insertAiExplanationSchema = createInsertSchema(aiExplanations).omit({
  id: true,
  createdAt: true,
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({
  id: true,
  unlockedAt: true,
});

export const insertSyllabusSchema = createInsertSchema(syllabi).omit({
  id: true,
  createdAt: true,
});

export const insertPastQuestionPaperSchema = createInsertSchema(pastQuestionPapers).omit({
  id: true,
  uploadedAt: true,
});

export const insertPastQuestionSchema = createInsertSchema(pastQuestions).omit({
  id: true,
  createdAt: true,
});

export const insertSyllabusProgressSchema = createInsertSchema(syllabusProgress).omit({
  id: true,
});

// Login schema
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = z.infer<typeof insertSubjectSchema>;
export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;
export type MockExam = typeof mockExams.$inferSelect;
export type InsertMockExam = z.infer<typeof insertMockExamSchema>;
export type AiExplanation = typeof aiExplanations.$inferSelect;
export type InsertAiExplanation = z.infer<typeof insertAiExplanationSchema>;
export type UserAchievement = typeof userAchievements.$inferSelect;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type Syllabus = typeof syllabi.$inferSelect;
export type InsertSyllabus = z.infer<typeof insertSyllabusSchema>;
export type PastQuestionPaper = typeof pastQuestionPapers.$inferSelect;
export type InsertPastQuestionPaper = z.infer<typeof insertPastQuestionPaperSchema>;
export type PastQuestion = typeof pastQuestions.$inferSelect;
export type InsertPastQuestion = z.infer<typeof insertPastQuestionSchema>;
export type SyllabusProgress = typeof syllabusProgress.$inferSelect;
export type InsertSyllabusProgress = z.infer<typeof insertSyllabusProgressSchema>;
export type LoginData = z.infer<typeof loginSchema>;
