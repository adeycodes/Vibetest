# EasyFrontend Generated Project

Website: [http://easyfrontend.com](http://easyfrontend.com/)


## Usefull links
Documentation: [http://help.easyfrontend.com](http://help.easyfrontend.com/)
